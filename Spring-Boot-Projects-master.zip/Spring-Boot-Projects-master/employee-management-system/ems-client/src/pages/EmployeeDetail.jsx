


const EmployeeDetail = () => {

    return (
        <div>Detail</div>
    )
}

export default EmployeeDetail;