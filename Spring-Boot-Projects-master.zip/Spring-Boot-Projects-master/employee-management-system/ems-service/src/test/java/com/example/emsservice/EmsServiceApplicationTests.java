package com.example.emsservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
